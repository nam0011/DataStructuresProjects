/*  Nathan Moore
 *  8/22/20
 *  CS221-01
 *  Player Stat Calculator Using User Input to Gather Variable Values
 */

#include "PlayerStats.h" //including header file to include all class functions as well as default cpp librarys and namespace


int main() {        //begin of main function

    PlayerStats baseballPlayer;     //creating an object called baseballPlayer

    baseballPlayer.statsCalc();     //running public function statsCalc to enter and return player stats

    return 0;       //returning 0 to console if program executed and closed properly
}


//****** Another way to run this program using main function to do a lot of the work ******

/*   string firstName = "unknown", lastName = "unknown";
   int plateAppearances = 0, atBats = 0;
   int singles = 0, doubles = 0, triples = 0;
   int homeRuns = 0, walks = 0, hitByPitch = 0;
   char answer = 'N';
   PlayerStats baseballPlayer;



   do{             //loop used to gather information about baseball players and output batting average and on base percentage to console

       cout << "Enter Player Data: ";
       cin >> firstName >> lastName >> plateAppearances >> atBats >> singles >> doubles >> triples >> homeRuns >> walks
           >> hitByPitch;

       baseballPlayer.getData();
*/

/*
       if(lastName.back() == 's'){                 //if else statement to see if players last name ends in an "s" and depending on check displays correct possessive proper noun

           cout << firstName << " "<< lastName<<"'";
           baseballPlayer.AVG();
           baseballPlayer.OBP();
           cout<<endl;

       }else {
           cout << firstName << " " << lastName << "'s ";
           baseballPlayer.AVG();
           baseballPlayer.OBP();
           cout << endl;
       }

       cout<<"Do you wish to enter another players information?: ";            //allowing user to update answer variable and either run loop a second+ time or end program
       cin>>answer;

   }
   while(answer == 'Y' || answer == 'y');



*/
