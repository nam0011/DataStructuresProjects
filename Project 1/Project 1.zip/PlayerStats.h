/*  Nathan Moore
 *  8/22/20
 *  CS221-01
 *  Header for main program to access Baseball Player Stat Calculator
 */


#include <iomanip>          //declaring standard namespace and default cpp libaries to be included within header file
#include <iostream>

using namespace std;


class PlayerStats {
public:    //public functions for main to call to reach private function abilities

    void statsCalc();

private:                    //Private variables  and functions to class Player

    void playerInitialize();
    void getData(int stats[]);
    void OBP();
    void AVG();
    void read();
    void printName(string fName, string lName);
    void repeat();

    double battingAverage(int single, int doub, int triple, int homeRun, int atBat);
    double onBasePercentage(int single, int doub, int triple, int homeRun, int walk, int hitByPitch, int plateAppearances);

    double printAVG , printOBP;

    string firstName , lastName ;
    int plateAppearances, atBats;
    int singles , doubles, triples;
    int homeRuns, walks = 0, hitByPitch;

    char answerMain = 'N';
};