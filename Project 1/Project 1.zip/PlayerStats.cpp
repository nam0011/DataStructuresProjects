/*  Nathan Moore
 *  8/22/20
 *  CS221-01
 *  PlayerStats.cpp made to define public and private class functions used by end user to calculate and display player attributes
 */


#include "PlayerStats.h"

    void PlayerStats::playerInitialize(){       //Player Constructor initialization
        firstName = "unknown", lastName = "unkown";
        plateAppearances = 0, atBats = 0;
        singles = 0, doubles = 0, triples = 0;
        homeRuns = 0, walks = 0, hitByPitch = 0;
        printAVG = 0, printOBP = 0;
    }

    void PlayerStats::statsCalc(){
        do {
            playerInitialize();
            read();
            printName(firstName, lastName);
            AVG();
            OBP();
            repeat();
        }while(answerMain == 'Y' || answerMain == 'y');
        if(answerMain == 'N' || answerMain == 'n'){
            cout << "Program One Testing Complete"<<endl;
        }
    }

    void PlayerStats::read() {
    cout << "Enter Player Data: ";
    cin >> firstName >> lastName >> plateAppearances >> atBats >> singles >> doubles >> triples >> homeRuns >> walks
        >> hitByPitch;
    int stats[8] = {plateAppearances, atBats, singles, doubles, triples, homeRuns, walks, hitByPitch};
        getData(stats);
    }

    void PlayerStats::getData(int stats[]) {


        battingAverage(stats[2], stats[3], stats[4], stats[5], stats[1]);

        onBasePercentage(stats[2], stats[3], stats[4], stats[5], stats[6], stats[7], stats[0]);

    }

    void PlayerStats::OBP(){             //function to print on base percentage
        cout << "OBP = " << setprecision(3) << printOBP << " " <<endl;
    }

    void PlayerStats::AVG(){            //function to print batting average
        cout << "Batting Average = " << setprecision(3) << printAVG << " ";
    }

    void PlayerStats::printName(string fName, string lName){
        if(lName.back() == 's'){                 //if else statement to see if players last name ends in an "s" and depending on check displays correct possessive proper noun
            cout <<"     " << fName << " "<< lName<<"' ";
        }else {
            cout <<"     " << fName << " " << lName << "'s ";
        }
    }

    void PlayerStats::repeat(){
        char answer;

        cout<<endl;
        cout<<"Do you wish to enter another players information?: ";            //allowing user to update answer variable and either run loop a second+ time or end program
        cin>>answer;
        cout<<endl;
        answerMain = answer;
    }

    double PlayerStats::battingAverage(int single, int doub, int triple, int homeRun, int atBat) {       //function to calculate batting average

        double batAvg;
        double totHits = 0;

        totHits = single + doub + triple + homeRun;       //calculation for finding batting average

        batAvg = totHits / atBat;                     //storing batting average
        printAVG = batAvg;

        return batAvg;
    }

    double PlayerStats::onBasePercentage(int single, int doub, int triple, int homeRun, int walk, int hitByPitch, int plateAppearances) {       //function to calculate on base percentage

        double oBP;
        double allHits;

        allHits = single + doub + triple + homeRun + walk +
                  hitByPitch;       //calculations for finding on base percentage

        oBP = allHits / plateAppearances;                            //storing on Base Percentage
        printOBP = oBP;
        return oBP;
    }
