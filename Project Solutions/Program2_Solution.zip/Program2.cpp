/* File: Program1.cpp
   BETH ALLEN
   AUGUST 2018,   CS221 FALL 2018
   This program test drives the BaseballPlayer class.  It will be used to read data to and from input/output data files

   The general operation of this program is to read one baseball player at a time from one line of the input file until the end of the file is found.
   Players are added to the player list as they are read in.

   After all players are added, then the team average can be computed. And then the data is written to an output report.

 */

using namespace std;
#include <iostream>	
#include <fstream>
#include <iomanip>

#include "PlayerList.h"


//-----------------------------------------------------------------------------------------------//
// Main program
// Uses a single variable to store a player temporarily until it is added to the list.
// The loop reuses the variable over and over until all lines of the input file have been 
// retrieved.
//-----------------------------------------------------------------------------------------------//

int main(void) {
	string   inFileName, outFileName;		// names of the input and output data files supplied by the user
	ifstream inputFile;						// input file handle
	ofstream outputFile;					// output file handle
	BaseballPlayer  p1;						// a temporary  object = the current player being read or printed
	PlayerList myTeamRoster;				// the list storage
	
	cout << "Welcome to the player statistics calculator test program.  I am going to\n";
	cout << "read players from an input data file.  You will tell me the names of\n";
	cout << "your input and output files.  I will store all of the players in a list, \n";
	cout << "compute each player's average and then write the resulting team report \n";
	cout << "to your output file.\n\n";

	cout << "\n\n";

	
	cout << "Enter the name of your input file:  ";  cin >> inFileName;
	cout << "Enter the name of your output file: ";  cin >> outFileName;

	// opening data files
	inputFile.open(inFileName.c_str());
	if (inputFile.fail()) { 
		cout << "Sorry. I could not open your input file - " << inFileName << "-\n";
		cout << "Exiting the program.\n";  return 1;
	}
	outputFile.open(outFileName.c_str());
	if (outputFile.fail()) { 
		cout << "Sorry. I could not open your output file - " << outFileName << "-\n";
		cout << "Exiting the program.\n";  return 1;
	}

	cout << "Reading Players from " << inFileName << endl;
	int count = 0;   // tbd later
	while (!inputFile.eof()) {
		p1.read(inputFile);
		p1.computeStats();
		myTeamRoster.add(p1);   // add this player to the list
	}

	myTeamRoster.calculate();  // perform computations on roster
	outputFile << "BASEBALL TEAM REPORT --- " << myTeamRoster.getCount() << " PLAYERS FOUND IN FILE\n";
	outputFile << "OVERALL BATTING AVERAGE is " << std::fixed << std::setprecision(3) << myTeamRoster.getAverage();
	outputFile << endl <<endl;

	outputFile << "    PLAYER NAME      :    AVERAGE    OPS\n";
	outputFile << "----------------------------------------------\n";

	myTeamRoster.resetIteration(); // get ready to visit each student
	while (myTeamRoster.hasNext()) {
		p1 = myTeamRoster.getNext();
		outputFile << setw(20) << p1.getLastName() + ", " + p1.getFirstName();
		outputFile << " :    " << setw(6) << setprecision(3) << p1.getBattingAverage();
		outputFile << "   " << setw(6) << setprecision(3) << p1.getOPS();
		outputFile << endl;
	}

	cout << "The data has been written to your output file: " << outFileName << endl;

	inputFile.close();
	outputFile.close();

	cout << "\n\n";
	cout << "End of Program 2\n";

	return 0;
}