#include <string>
#include "BaseballPlayer.h"
using namespace std;
//***************************************************************************//
/* FILE: PlayerList.h    Singly Linked List Implementation
   Class: PlayerList
   This class maintains a player list with no fixed capacity
   
   Public Methods:
        PlayerList - default constructor
        add     	- add a player to the list
		resetIteration - to start at the beginning of the list array
		getNext     - get a copy of the next player in the list
		hasNext     - true/false if there is another player to get
		calculate   - perform computations related to the team average
		getAverage  - get the team average
		clear		- initialize the list to a clean state, including deleting the allocated nodes
		getCount    - gets the count of items in the list
		isEmpty     - test to see if list is empty
		Constructor, Destructor 

*/

class Node {
public:
	BaseballPlayer item;		// a baseball player object stored in the list
	Node          *pNext;       // pointer to the next node in the list
	Node(const BaseballPlayer& player);  // constructor used to copy in a player when a new node is created
};

class PlayerList {
	Node    *pFirst;				// pointer to the first node in this list
	Node    *pLast;					// pointer to the last  node in this list
	int      mPlayerCount;			// number of items stored in the list
	Node    *pCurrent;				// pointer to the current node in a list iteration operations
	double   mAverage;				// overall team average

public:
	PlayerList();
   ~PlayerList();
	bool	 add(const BaseballPlayer &);
	void	 resetIteration();
	BaseballPlayer getNext();
	bool	 hasNext();
	void	 calculate();
	double	 getAverage();
	void	 clear();
	int		 getCount();
	bool	 isEmpty();
};
	