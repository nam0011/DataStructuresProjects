#include "PlayerList.h"
using namespace std;
//***************************************************************************//
/* FILE: PlayerList.cpp
   Class: PlayerList
   This is the implementation file for the methods defined in class
   PlayerList. Please see PlayerList.h for a description of the interface
*/

//---------------------------------------------------------------------------//
// Node Constructor:  Nodes used with this list store a player object that
// is copied in when the node is constructed with the new operation
//---------------------------------------------------------------------------//
Node::Node(const BaseballPlayer& player) {
	item = player;
	pNext = NULL;
}

//---------------------------------------------------------------------------//
// Constructor: Default
// This constructor initializes a PlayerList to a pristine state.
// The index reflects the fact that the internal array is empty.
//---------------------------------------------------------------------------//	
PlayerList::PlayerList() {   // set all  pointers to NULL and count to 0
	pFirst = NULL;
	pLast = NULL;
	pCurrent = NULL;
	mPlayerCount = 0;
}


//---------------------------------------------------------------------------//
// Destructor: Default
// This destructor calls the clear() method when this list ceases to exist
// in a program scope.  Clear will handle deleting all of the nodes and
// resetting pointers.
//---------------------------------------------------------------------------//	
PlayerList::~PlayerList() {  
	clear();
}
//---------------------------------------------------------------------------//
// add(P) : takes the input player and copies it into the list
//---------------------------------------------------------------------------//
bool PlayerList::add(const BaseballPlayer &player) {
	bool success = false;
	Node* pNew = new Node(player);  // create node and copy player into it
	if (pFirst == NULL) { // then this list is empty and our new node is the first node
		pFirst = pNew;
	}
	else {
		pLast->pNext = pNew;  // otherwise, link to the end
	}
	pLast = pNew;   // the new node is always the new last node
	return success;
}

//---------------------------------------------------------------------------//
// resetIteration() - gets this list ready to begin an iteration through
// its data
//---------------------------------------------------------------------------//
void PlayerList::resetIteration() {
	pCurrent = pFirst;  // starts at front of array for data retrieval
}

//---------------------------------------------------------------------------//
// getNext()
// Returns a copy of next item in the iteration. If the list is at the end, 
// do not move the index over anymore
// Returns one baseball player object
//---------------------------------------------------------------------------//
BaseballPlayer PlayerList::getNext( ) {
	BaseballPlayer temp;
	if (pCurrent != NULL) {
		temp = pCurrent->item;
		pCurrent = pCurrent->pNext;
	}
	return temp;
}

//---------------------------------------------------------------------------//
// hasNext()
// Returns true if there are more items in the list to be iterated through
//---------------------------------------------------------------------------//
bool PlayerList::hasNext()
{
	return (pCurrent != NULL);
}

//---------------------------------------------------------------------------//
// calculate()
// Instructs the list to perform internal, list wide computation(s) 
// Computes the overall team average
//---------------------------------------------------------------------------//
void PlayerList::calculate() {
	double sumAverages = 0.0;
	Node *p;
	p = pFirst;
	while (p != NULL) {
		sumAverages = sumAverages + p->item.getBattingAverage();
		p = p->pNext;
	}
	if (mPlayerCount > 0)
		mAverage = sumAverages / mPlayerCount;
	else
		mAverage = 0.0;  // to be safe, don't divide by 0!
}

//---------------------------------------------------------------------------//
//---------------------------------------------------------------------------//
double PlayerList::getAverage() {
	return mAverage;
}

//---------------------------------------------------------------------------//
// clear() - sets the list to an empty state
// It walks the list and deletes each node in the list, then sets all 
// relevant pointers to NULL.
//---------------------------------------------------------------------------//
void PlayerList::clear() {
	Node* p;   // temp pointer for walking list
	p = pFirst;
	while (p != NULL) {
		p = p->pNext;
		delete pFirst;
		pFirst = p;
	}
	mPlayerCount = 0;
	pCurrent = NULL;
	pFirst = NULL;
	pLast = NULL;
	mAverage = 0.0;
}

//---------------------------------------------------------------------------//
// getCount() - returns the count of students currently in this list
//---------------------------------------------------------------------------//
int  PlayerList::getCount() {
	return mPlayerCount;
}

//---------------------------------------------------------------------------//
// isEmpty() - returns true if the list is empty, false otherwise 
//---------------------------------------------------------------------------//
bool PlayerList::isEmpty() {
	return (pFirst == NULL);
}